package com.example.sssmobileapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
