// ignore_for_file: use_build_context_synchronously

import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:sssmobileapp/config/style.dart';

class Api {
  static String? appVersion;
  static String _token = '';
  static String get device => Platform.isIOS
      ? 'IOS'
      : Platform.isAndroid
          ? 'Android'
          : 'other';
  // Live Server
  static String get baseUrl => 'https://beta.swiftexsecurity.com/api/';
  static String get linkUrl => 'https://beta.swiftexsecurity.com/';

  static String get token => _token;
  static set setToken(String gToken) {
    _token = gToken;
  }

  // static setAppVersion() async {
  //   packageInfo = await PackageInfo.fromPlatform();

  //   appVersion = packageInfo!.version;
  //   print({'App Version: $appVersion'});
  // }

  static Future<Response> get(String endPoint,
      {Map<String, String>? header, Map<String, dynamic>? parameters}) {
    var dio = Dio();
    // header ??= {};
    // header['Authorization'] = 'Bearer $token';
    // header['version'] = appVersion!;
    // header['device'] = device;

    dio.options =
        BaseOptions(headers: header, validateStatus: (x) => x != null);
    return dio.get(baseUrl + endPoint);
  }

  static Future<Response> put(String endpoint,
      {Map<String, String>? queryParameters,
      Map<String, String>? headers,
      Map<String, dynamic>? data}) {
    var dio = Dio();
    // headers ??= {};
    // headers['Authorization'] = 'Bearer $token';
    // headers['version'] = appVersion!;
    // headers['device'] = device;
    dio.options =
        BaseOptions(headers: headers, queryParameters: queryParameters);
    dio.options =
        BaseOptions(headers: headers, validateStatus: (x) => x != null);

    return dio.put(baseUrl + endpoint, data: data);
  }

  static Future<Response> post(String endpoint,
      {Map<String, String>? headers, dynamic data, CancelToken? cancelToken}) {
    var dio = Dio()..options = BaseOptions(validateStatus: (x) => x != null);
    // headers ??= {};
    // headers['Authorization'] = 'Bearer $token';
    // headers['version'] = appVersion!;
    // headers['device'] = device;
    // dio.options = BaseOptions(
    //   headers: headers,
    //   validateStatus: (status) => status != null,
    // );
    var post =
        dio.post(baseUrl + endpoint, data: data, cancelToken: cancelToken);
    // pprint({'connection time out': dio.options.connectTimeout});
    return post;
  }

  static Future<Response> delete(
    String endpoint, {
    Map<String, String>? headers,
    Map<String, String>? queryParameters,
    dynamic data,
  }) {
    var dio = Dio()..options = BaseOptions(validateStatus: (x) => x != null);
    headers ??= {};
    headers['Authorization'] = 'Bearer $token';
    headers['version'] = appVersion!;
    headers['device'] = device;
    dio.options = BaseOptions(
      headers: headers,
      validateStatus: (status) => status != null,
    );

    return dio.delete(baseUrl + endpoint);
  }

  static showDialogOnApi(context, dialog,
      {Widget? icon, Color? backgroundColor, Color? textColor}) {
    // Navigator.pop(context);
    if (dialog != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: RichText(
          text: TextSpan(
            children: [
              if (icon != null) WidgetSpan(child: icon),
              TextSpan(
                  text: dialog,
                  style: TextStyle(
                    color: textColor ?? Colors.white,
                    fontSize: backgroundColor != null ? 14 : 16,
                    fontFamily: 'PPMori',
                  ))
            ],
          ),
          textAlign: TextAlign.center,
        ),
        dismissDirection: DismissDirection.up,
        backgroundColor: backgroundColor ?? AppTheme.backgroundColor,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        margin: EdgeInsets.only(
            // top: 20,
            bottom: MediaQuery.sizeOf(context).height - 144,
            right: 20,
            left: 20),
      ));
    }
    // ScaffoldMessenger.of(context).showMaterialBanner(
    //   MaterialBanner(
    //     backgroundColor: blackColor,
    //     content: Text(dialog),
    //     actions: [
    //       GCFilledButton(
    //           size: Size(50, 30),
    //           onPressed: () {
    //             ScaffoldMessenger.of(context).clearMaterialBanners();
    //           },
    //           widget: Text('OK'))
    //     ],
    //     onVisible: () {
    //       Future.delayed(Duration(seconds: 2)).then(
    //           (value) => ScaffoldMessenger.of(context).clearMaterialBanners());
    //     },
    //   ),
    // );
  }

  static showSnackBarOnDialog(BuildContext context, String title,
      {Widget? icon, Color? backgroundColor, Color? textColor}) {
    showDialog(
        barrierDismissible: false,
        barrierColor: Colors.transparent,
        context: context,
        builder: (dc) {
          Future.delayed(const Duration(seconds: 3))
              .then((value) => Navigator.pop(dc));
          return AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
            alignment: Alignment.topCenter,
            insetPadding: const EdgeInsets.all(20).copyWith(top: 50),
            contentPadding: const EdgeInsets.all(20),
            backgroundColor: backgroundColor ?? AppTheme.backgroundColor,
            shadowColor: Colors.transparent,
            content: RichText(
              text: TextSpan(
                children: [
                  if (icon != null) WidgetSpan(child: icon),
                  TextSpan(
                      text: title,
                      style: TextStyle(
                        color: textColor ?? Colors.white,
                        fontSize: backgroundColor != null ? 14 : 16,
                        fontFamily: 'PPMori',
                      ))
                ],
              ),
              textAlign: TextAlign.center,
            ),
          );
        });
  }
}
