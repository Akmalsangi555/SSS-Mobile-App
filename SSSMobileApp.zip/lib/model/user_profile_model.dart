// To parse this JSON data, do
//
//     final userProfileModel = userProfileModelFromJson(jsonString);

class UserProfileModel {
  String email;
  int usersProfileId;
  String? fullName;
  String? profilePhoto;
  String? phone;
  String? gender;
  int usersProfileTypeId;
  int organizationId;

  int branchId;
  int guardsTypeId;
  int guardsId;
  int clientId;

  UserProfileModel(
      {required this.email,
      required this.usersProfileId,
      this.fullName,
      this.profilePhoto,
      required this.usersProfileTypeId,
      required this.organizationId,
      required this.branchId,
      required this.guardsTypeId,
      required this.guardsId,
      required this.clientId,
      this.phone,
      this.gender});

  factory UserProfileModel.fromJson(Map<String, dynamic> json, String? email) =>
      UserProfileModel(
        email: email ?? json['UserName'],
        phone: json["Phone"],
        gender: json["Gender"],
        usersProfileId: json["UsersProfile_ID"],
        fullName: json["FullName"],
        profilePhoto: json["ProfilePhoto"],
        usersProfileTypeId: json["UsersProfileType_ID"],
        organizationId: json["Organization_ID"],
        branchId: json["Branch_ID"],
        guardsTypeId: json["GuardsType_ID"],
        guardsId: json["Guards_ID"],
        clientId: json["Client_ID"],
      );

  Map<String, dynamic> toJson() => {
        "UsersProfile_ID": usersProfileId,
        "Email": email,
        "Phone": phone,
        "Gender": gender,
        "FullName": fullName,
        "ProfilePhoto": profilePhoto,
        "UsersProfileType_ID": usersProfileTypeId,
        "Organization_ID": organizationId,
        "Branch_ID": branchId,
        "GuardsType_ID": guardsTypeId,
        "Guards_ID": guardsId,
        "Client_ID": clientId,
      };
}
