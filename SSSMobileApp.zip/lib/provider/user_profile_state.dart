import 'package:flutter/material.dart';
import 'package:sssmobileapp/model/user_profile_model.dart';

class UserProfileState with ChangeNotifier {
  UserProfileModel? _userData;

  UserProfileModel? get userData => _userData;

  void setUserData(UserProfileModel userData) {
    _userData = userData;
    notifyListeners();
  }
}
