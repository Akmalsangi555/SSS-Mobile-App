import 'package:flutter/material.dart';
import 'package:sssmobileapp/model/leaves_model.dart';

class LeaveState with ChangeNotifier {
  List<LeavesModel> _leaves = [];

  List<LeavesModel> get leaves => _leaves;

  set leaves(List<LeavesModel> leaves) {
    _leaves = leaves;
    notifyListeners();
  }
}
