import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sssmobileapp/config/style.dart';
import 'package:sssmobileapp/provider/leave_state.dart';
import 'package:sssmobileapp/provider/user_profile_state.dart';
import 'package:sssmobileapp/view/onboarding/signin.dart';

void main() {
  runApp(MultiProvider(providers: [
    ChangeNotifierProvider(
      create: (_) => UserProfileState(),
    ),
    ChangeNotifierProvider(
      create: (_) => LeaveState(),
    )
  ], child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SSS Mobile App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Poppins',
        appBarTheme: AppBarTheme(
          foregroundColor: Colors.white,
          backgroundColor: AppTheme.backgroundColor,
          shadowColor: Colors.transparent,
        ),
        textButtonTheme: TextButtonThemeData(
          style: ButtonStyle(
            foregroundColor: WidgetStateProperty.all(Colors.blue),
            textStyle: WidgetStateProperty.all(const TextStyle(
                fontSize: 12, fontWeight: FontWeight.bold, color: Colors.blue)),
          ),
        ),
        textTheme: TextTheme(
            bodyMedium: TextStyle(
              fontSize: 14,
              color: AppTheme.primaryTextColor,
            ),
            bodySmall: TextStyle(
              fontSize: 12,
              color: AppTheme.primaryTextColor,
            )),
        inputDecorationTheme: InputDecorationTheme(
          hintStyle: TextStyle(color: Color(0xFFCACACA), fontSize: 14),
          labelStyle: TextStyle(color: Color(0xFFCACACA), fontSize: 14),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(
                color: Color(0xFFCBCBCB),
              )),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(
                color: AppTheme.backgroundColor,
              )),
          enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(
                color: Color(0xFFCBCBCB),
              )),
          errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(
                color: Colors.red,
              )),
        ),
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: false,
      ),
      home: const SignIn(),
    );
  }
}
