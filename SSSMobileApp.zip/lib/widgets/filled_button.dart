import 'package:flutter/material.dart';
import 'package:sssmobileapp/config/style.dart';

class SSSFilledButton extends StatelessWidget {
  const SSSFilledButton(
      {super.key,
      this.child,
      required this.buttonText,
      this.onPressed,
      this.bgColor,
      this.textColor});
  final Widget? child;
  final String buttonText;
  final Color? bgColor;
  final Color? textColor;
  final void Function()? onPressed;
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          fixedSize: Size(double.infinity, 44),
          backgroundColor: bgColor ?? AppTheme.backgroundColor,
          foregroundColor: textColor ?? AppTheme.primaryTextButtonColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        onPressed: onPressed,
        child: child ?? Text(buttonText));
  }
}
