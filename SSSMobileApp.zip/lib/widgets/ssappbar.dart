import 'package:flutter/material.dart';
import 'package:sssmobileapp/view/notification/notification_view.dart';

AppBar ssAppBar(String titleOfPage, BuildContext context) {
  return AppBar(
    leadingWidth: 70,
    title: Text(titleOfPage),
    actions: [
      IconButton(
          onPressed: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => NotificationView()));
          },
          icon: Icon(Icons.notifications)),
      // IconButton(onPressed: () {}, icon: Icon(Icons.logout)),
    ],
  );
}
