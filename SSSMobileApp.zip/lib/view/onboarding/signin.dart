import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sssmobileapp/api_function.dart';
import 'package:sssmobileapp/model/user_profile_model.dart';
import 'package:sssmobileapp/provider/user_profile_state.dart';
import 'package:sssmobileapp/view/onboarding/forget_passwod_r_code.dart';
import 'package:sssmobileapp/widgets/bottom_nav.dart';
import 'package:sssmobileapp/widgets/filled_button.dart';
import 'package:sssmobileapp/widgets/sscaffold.dart';

class SignIn extends StatefulWidget {
  const SignIn({
    super.key,
  });

  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool apoLoading = false;
  @override
  Widget build(BuildContext context) {
    return SScaffold(
      titleOfPage: 'Sign in',
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Image.asset(
                'assets/images/logo.png',
                height: 250,
              ),
              Text(
                'Good to see you!\nSign in to access your dashboard.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 16,
              ),
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      controller: _emailController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your email';
                        } else if (!value.contains('@')) {
                          return 'Please enter your email';
                        }
                        return null;
                      },
                      decoration: InputDecoration(
                        label: Text('Email'),
                      ),
                    ),
                    SizedBox(
                      height: 16,
                    ),
                    TextFormField(
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your password';
                        }
                        return null;
                      },
                      obscureText: true,
                      controller: _passwordController,
                      decoration: InputDecoration(
                        label: Text('Password'),
                      ),
                    ),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.topRight,
                child: TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => ForgetPasswordRCode()));
                    },
                    child: Text('Forgot your password ?')),
              ),
              SizedBox(
                height: 32,
              ),
              SizedBox(
                width: double.infinity,
                child: SSSFilledButton(
                  onPressed: () async {
                    setState(() {
                      apoLoading = true;
                    });
                    if (!_formKey.currentState!.validate()) {
                      return;
                    }
                    try {
                      var res = await Api.post('AuthAPI/Login', data: {
                        'email': _emailController.text,
                        'password': _passwordController.text,
                        "lat": "31.5204",
                        "lon": "74.3587",
                        "os": "Android",
                        "location": "Lahore"
                      });
                      print(res);

                      if (res.statusCode == 200) {
                        var data = res.data;
                        context.read<UserProfileState>().setUserData(
                            UserProfileModel.fromJson(
                                data['Content'], _emailController.text));

                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => BottomNav()));
                      } else {
                        Api.showDialogOnApi(context, res.data['Message']);
                      }
                    } catch (e) {
                      if (kDebugMode) {
                        print(e);
                      }
                      Api.showDialogOnApi(context, "Something went wrong");
                    } finally {
                      setState(() {
                        apoLoading = false;
                      });
                    }
                  },
                  buttonText: 'Sign in',
                  child: apoLoading ? CircularProgressIndicator() : null,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
