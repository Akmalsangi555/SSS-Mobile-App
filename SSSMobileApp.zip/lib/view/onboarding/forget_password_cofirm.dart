import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sssmobileapp/api_function.dart';
import 'package:sssmobileapp/config/style.dart';
import 'package:sssmobileapp/view/onboarding/change_password.dart';
import 'package:sssmobileapp/widgets/filled_button.dart';
import 'package:sssmobileapp/widgets/sscaffold.dart';

class ForgetPasswordConfirm extends StatefulWidget {
  const ForgetPasswordConfirm(
      {super.key, required this.email, required this.userId});
  final String email;
  final int userId;

  @override
  State<ForgetPasswordConfirm> createState() => _ForgetPasswordConfirmState();
}

class _ForgetPasswordConfirmState extends State<ForgetPasswordConfirm> {
  bool isApiCallInProgress = false;
  bool isConfirmApiCallInProgress = false;
  final _formKey = GlobalKey<FormState>();
  TextEditingController codeController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SScaffold(
      titleOfPage: 'Forget password',
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
                'A code has been sent to your email. Check inbox or spam and enter it below to reset your password.'),
            SizedBox(
              height: 16,
            ),
            Row(
              children: [
                Expanded(
                  child: Form(
                    key: _formKey,
                    child: TextFormField(
                      controller: codeController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Invalid code. Please try again.';
                        }
                        return null;
                      },
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: 'Type a code',
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 8,
                ),
                SSSFilledButton(
                  bgColor: AppTheme.requestBGButtonColor,
                  buttonText: 'Resend',
                  onPressed: () async {
                    if (!isApiCallInProgress) {
                      try {
                        setState(() {
                          isApiCallInProgress = true;
                        });
                        var res = await Api.post('AuthAPI/ForgotPassword',
                            data: {'email': widget.email});
                        if (kDebugMode) {
                          print(res.data);
                        }
                        if (res.statusCode == 200 &&
                            res.data['IsSuccess'] == true) {
                          Api.showSnackBarOnDialog(
                              context, res.data['Message']);
                        } else {
                          Api.showSnackBarOnDialog(
                              context, res.data['Message']);
                        }
                      } catch (e) {
                        if (kDebugMode) {
                          print(e);
                        }
                        Api.showSnackBarOnDialog(
                            context, "Something went wrong");
                      } finally {
                        setState(() {
                          isApiCallInProgress = false;
                        });
                      }
                    }
                  },
                ),
              ],
            ),
            SizedBox(
              height: 32,
            ),
            SizedBox(
              width: double.infinity,
              child: SSSFilledButton(
                buttonText: 'Verify',
                onPressed: () async {
                  if (!isConfirmApiCallInProgress) {
                    if (!_formKey.currentState!.validate()) {
                      return;
                    }
                    try {
                      setState(() {
                        isConfirmApiCallInProgress = true;
                      });
                      int code = int.parse(codeController.text.trim());
                      var res = await Api.post('AuthAPI/VerifyResetCode',
                          data: {"UserId": widget.userId, "Code": code});
                      if (res.statusCode == 200 &&
                          res.data['IsSuccess'] == true) {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => ChangePassword(
                                      userId: widget.userId,
                                      code: code,
                                    )));
                      } else {
                        Api.showDialogOnApi(context, res.data['Message']);
                      }
                    } catch (e) {
                      if (kDebugMode) {
                        print(e);
                      }
                      Api.showDialogOnApi(context, 'Something went wrong');
                    } finally {
                      setState(() {
                        isConfirmApiCallInProgress = false;
                      });
                    }
                  }
                },
                child: isConfirmApiCallInProgress
                    ? CircularProgressIndicator()
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
