import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sssmobileapp/api_function.dart';
import 'package:sssmobileapp/config/style.dart';
import 'package:sssmobileapp/view/onboarding/signin.dart';
import 'package:sssmobileapp/widgets/filled_button.dart';
import 'package:sssmobileapp/widgets/sscaffold.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({super.key, required this.userId, required this.code});
  final int userId;
  final int code;
  @override
  State<ChangePassword> createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  bool isApiCalling = false;
  final _formKey = GlobalKey<FormState>();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmedPasswordController = TextEditingController();
  bool showPassword = false;
  bool showConfirmedPassword = false;
  @override
  Widget build(BuildContext context) {
    return SScaffold(
        titleOfPage: 'Change password',
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 32,
                ),
                Text(
                  'Type your new password',
                  style:
                      TextStyle(fontSize: 12, color: AppTheme.secondaryColor),
                ),
                SizedBox(
                  height: 4,
                ),
                TextFormField(
                  controller: passwordController,
                  obscureText: !showPassword,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your password.';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                      hintText: 'New password',
                      suffixIcon: IconButton(
                          icon: Icon(showPassword
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () {
                            setState(() {
                              showPassword = !showPassword;
                            });
                          })),
                ),
                SizedBox(
                  height: 16,
                ),
                Text(
                  'Confirm password',
                  style:
                      TextStyle(fontSize: 12, color: AppTheme.secondaryColor),
                ),
                SizedBox(
                  height: 4,
                ),
                TextFormField(
                  controller: confirmedPasswordController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your confirm password.';
                    }
                    return null;
                  },
                  obscureText: !showConfirmedPassword,
                  decoration: InputDecoration(
                      hintText: 'Confirm password',
                      suffixIcon: IconButton(
                          icon: Icon(showConfirmedPassword
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () {
                            setState(() {
                              showConfirmedPassword = !showConfirmedPassword;
                            });
                          })),
                ),
                SizedBox(
                  height: 48,
                ),
                SizedBox(
                  width: double.infinity,
                  child: SSSFilledButton(
                    buttonText: 'Change password',
                    onPressed: () async {
                      FocusManager.instance.primaryFocus?.unfocus();

                      if (!isApiCalling) {
                        if (!_formKey.currentState!.validate()) {
                          return;
                        } else if (passwordController.text !=
                            confirmedPasswordController.text) {
                          Api.showDialogOnApi(context,
                              'Password and confirmed password do not match.');
                          return;
                        }

                        try {
                          setState(() {
                            isApiCalling = true;
                          });
                          var res =
                              await Api.post('AuthAPI/UpdatePassword', data: {
                            "UserId": widget.userId,
                            "Code": widget.code,
                            "NewPassword": passwordController.text,
                            "ConfirmPassword": confirmedPasswordController.text
                          });
                          if (res.statusCode == 200 &&
                              res.data['IsSuccess'] == true) {
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                builder: (_) => SignIn(),
                              ),
                              (route) => false,
                            );
                          } else {
                            Api.showDialogOnApi(context, res.data['Message']);
                          }
                        } catch (e) {
                          if (kDebugMode) {
                            print(e);
                          }
                          Api.showDialogOnApi(context, e.toString());
                        } finally {
                          setState(() {
                            isApiCalling = false;
                          });
                        }
                      }
                    },
                    child: isApiCalling ? CircularProgressIndicator() : null,
                  ),
                ),
              ],
            ),
          ),
        ));
  }
}
