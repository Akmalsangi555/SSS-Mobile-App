import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sssmobileapp/api_function.dart';
import 'package:sssmobileapp/view/onboarding/forget_password_cofirm.dart';
import 'package:sssmobileapp/widgets/filled_button.dart';
import 'package:sssmobileapp/widgets/sscaffold.dart';

class ForgetPasswordRCode extends StatefulWidget {
  const ForgetPasswordRCode({super.key});

  @override
  State<ForgetPasswordRCode> createState() => _ForgetPasswordRCodeState();
}

class _ForgetPasswordRCodeState extends State<ForgetPasswordRCode> {
  TextEditingController emailController = TextEditingController();
  bool isApiCallInProgress = false;
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return SScaffold(
      titleOfPage: 'Forget password',
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Enter your email to reset your password'),
            SizedBox(
              height: 16,
            ),
            Form(
              key: _formKey,
              child: TextFormField(
                controller: emailController,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email.';
                  } else if (!value.contains('@')) {
                    return 'Invalid email. Please try again.';
                  }
                  return null;
                },
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: 'Email',
                ),
              ),
            ),
            SizedBox(
              height: 32,
            ),
            SizedBox(
              width: double.infinity,
              child: SSSFilledButton(
                buttonText: 'Get code',
                onPressed: () async {
                  if (!isApiCallInProgress) {
                    if (!_formKey.currentState!.validate()) {
                      return;
                    }

                    try {
                      setState(() {
                        isApiCallInProgress = true;
                      });
                      var res = await Api.post('AuthAPI/ForgotPassword',
                          data: {'email': emailController.text});
                      if (kDebugMode) {
                        print(res.data);
                      }
                      if (res.statusCode == 200 &&
                          res.data['IsSuccess'] == true) {
                        int userId = res.data['Content'];
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => ForgetPasswordConfirm(
                                      email: emailController.text,
                                      userId: userId,
                                    )));
                      } else {
                        Api.showSnackBarOnDialog(context, res.data['Message']);
                      }
                    } catch (e) {
                      if (kDebugMode) {
                        print(e);
                      }
                      Api.showSnackBarOnDialog(context, "Something went wrong");
                    } finally {
                      setState(() {
                        isApiCallInProgress = false;
                      });
                    }
                  }
                },
                child: isApiCallInProgress ? CircularProgressIndicator() : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
