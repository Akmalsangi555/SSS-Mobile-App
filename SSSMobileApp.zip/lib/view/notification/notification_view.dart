import 'package:flutter/material.dart';
import 'package:sssmobileapp/config/style.dart';
import 'package:sssmobileapp/widgets/ssappbar.dart';
import 'package:sssmobileapp/widgets/sscaffold.dart';

class NotificationView extends StatelessWidget {
  const NotificationView({super.key});

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> notifications = [
      {
        'title': 'Supervisor',
        'notification':
            'Reminder: Please check in on time for your scheduled shift today. Punctuality is important for smooth operations.',
        'date': '09/09/2025 Wed 05:03AM',
      },
      {
        'title': 'Client Manager',
        'notification':
            'Reminder: Please check in on time for your scheduled shift today. Punctuality is important for smooth operations.',
        'date': '09/09/2025 Wed 05:03AM',
      },
      {
        'title': 'Dispatch  Manager',
        'notification':
            'Reminder: Please check in on time for your scheduled shift today. Punctuality is important for smooth operations.',
        'date': '09/09/2025 Wed 05:03AM',
      },
    ];
    return SScaffold(
        appBar: ssAppBar('Notifications', context),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: notifications.map((e) {
                return Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: AppTheme.notificationBackgroundColor,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(e['title'],
                              style: TextStyle(
                                  color: AppTheme.backgroundColor,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold)),
                          Text(e['notification'],
                              style:
                                  TextStyle(color: AppTheme.primaryTextColor))
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 4,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text('  ${e['date']}',
                            style: TextStyle(
                                color: AppTheme.primaryTextColor, fontSize: 12))
                      ],
                    ),
                    SizedBox(height: 16)
                  ],
                );
              }).toList(),
            ),
          ),
        ));
  }
}
